<?php
$dir = "pages/";
$a = scandir($dir);
include_once("pages/landing-2.html");
?>
